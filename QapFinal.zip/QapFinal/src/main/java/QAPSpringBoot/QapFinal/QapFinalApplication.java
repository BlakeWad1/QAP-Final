package QAPSpringBoot.QapFinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QapFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(QapFinalApplication.class, args);
	}

}

package QAPSpringBoot.QapFinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QapFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
